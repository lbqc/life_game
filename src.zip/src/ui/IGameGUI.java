package ui;

/**
 * 游戏窗口
 */
public interface IGameGUI {

    /**
     * 重新展示游戏地图
     */
    void reShow();
}
