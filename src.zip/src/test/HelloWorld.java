package test;

import javax.swing.*;

public class HelloWorld {
    JPanel panel;
}
